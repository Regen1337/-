ITEM.name = "Adjustable Wrench"
ITEM.model = "models/mosi/fallout4/props/junk/adjustablewrench.mdl"
ITEM.description = "An adjustable wrench used for crafting."
ITEM.category = "Crafting Material"
ITEM.width = 1
ITEM.height = 1