ITEM.name = "Aluminum Bar"
ITEM.model = "models/mosi/fallout4/props/junk/components/aluminum.mdl"
ITEM.description = "An aluminum bar used for crafting."
ITEM.category = "Crafting Material"
ITEM.width = 1
ITEM.height = 1