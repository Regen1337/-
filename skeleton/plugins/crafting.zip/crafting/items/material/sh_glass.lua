ITEM.name = "Glass"
ITEM.model = "models/mosi/fallout4/props/junk/components/glass.mdl"
ITEM.description = "Glass used for crafting."
ITEM.category = "Crafting Material"
ITEM.width = 1
ITEM.height = 1