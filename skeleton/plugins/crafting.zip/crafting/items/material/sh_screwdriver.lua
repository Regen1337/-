ITEM.name = "Screwdriver"
ITEM.model = "models/mosi/fallout4/props/junk/screwdriver.mdl"
ITEM.description = "A screwdriver used for crafting."
ITEM.category = "Crafting Material"
ITEM.width = 1
ITEM.height = 1