ITEM.name = "Springs"
ITEM.model = "models/mosi/fallout4/props/junk/components/springs.mdl"
ITEM.description = "Springs used for crafting."
ITEM.category = "Crafting Material"
ITEM.width = 1
ITEM.height = 1