ITEM.name = "Steel Bar"
ITEM.model = "models/mosi/fallout4/props/junk/components/steel.mdl"
ITEM.description = "A steel bar used for crafting."
ITEM.category = "Crafting Material"
ITEM.width = 1
ITEM.height = 1