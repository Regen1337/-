ITEM.name = "Copper Bar"
ITEM.model = "models/mosi/fallout4/props/junk/components/copper.mdl"
ITEM.description = "A copper bar used for crafting."
ITEM.category = "Crafting Material"
ITEM.width = 1
ITEM.height = 1