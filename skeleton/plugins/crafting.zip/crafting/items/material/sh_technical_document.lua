ITEM.name = "Technical Document"
ITEM.model = "models/mosi/fallout4/props/junk/technicaldocument.mdl"
ITEM.description = "A technical document used for crafting."
ITEM.category = "Crafting Material"
ITEM.width = 1
ITEM.height = 1