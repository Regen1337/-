ITEM.name = "Plastic"
ITEM.model = "models/mosi/fallout4/props/junk/components/plastic.mdl"
ITEM.description = "Plastic used for crafting."
ITEM.category = "Crafting Material"
ITEM.width = 1
ITEM.height = 1