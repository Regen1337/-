ITEM.name = "Mod Box"
ITEM.model = "models/mosi/fallout4/props/junk/modbox.mdl"
ITEM.description = "A mod box used for crafting."
ITEM.category = "Crafting Material"
ITEM.width = 1
ITEM.height = 1