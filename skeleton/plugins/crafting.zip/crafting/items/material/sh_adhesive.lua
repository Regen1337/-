ITEM.name = "Adhesive"
ITEM.model = "models/mosi/fallout4/props/junk/components/adhesive.mdl"
ITEM.description = "A sticky substance used for crafting."
ITEM.category = "Crafting Material"
ITEM.width = 1
ITEM.height = 1