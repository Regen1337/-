ITEM.name = "Duct Tape"
ITEM.model = "models/mosi/fallout4/props/junk/ducttape.mdl"
ITEM.description = "A roll of duct tape used for crafting."
ITEM.category = "Crafting Material"
ITEM.width = 1
ITEM.height = 1