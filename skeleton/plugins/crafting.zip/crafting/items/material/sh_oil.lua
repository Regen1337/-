ITEM.name = "Oil"
ITEM.model = "models/mosi/fallout4/props/junk/components/oil.mdl"
ITEM.description = "Oil used for crafting."
ITEM.category = "Crafting Material"
ITEM.width = 1
ITEM.height = 1