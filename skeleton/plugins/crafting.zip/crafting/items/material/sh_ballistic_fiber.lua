ITEM.name = "Ballistic Fiber"
ITEM.model = "models/mosi/fallout4/props/junk/components/ballisticfiber.mdl"
ITEM.description = "A fiber used for crafting."
ITEM.category = "Crafting Material"
ITEM.width = 1