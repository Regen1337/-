ITEM.name = "Fiber Optic"
ITEM.model = "models/mosi/fallout4/props/junk/components/fiberoptic.mdl"
ITEM.description = "A fiber optic used for crafting."
ITEM.category = "Crafting Material"
ITEM.width = 1
ITEM.height = 1