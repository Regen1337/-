ITEM.name = "Ceramic"
ITEM.model = "models/mosi/fallout4/props/junk/components/ceramic.mdl"
ITEM.description = "A ceramic used for crafting."
ITEM.category = "Crafting Material"
ITEM.width = 1
ITEM.height = 1