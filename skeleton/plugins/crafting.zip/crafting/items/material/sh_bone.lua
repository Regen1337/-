ITEM.name = "Bone"
ITEM.model = "models/mosi/fallout4/props/junk/components/bone.mdl"
ITEM.description = "A bone used for crafting."
ITEM.category = "Crafting Material"
ITEM.width = 1
ITEM.height = 1
