ITEM.name = "Hide Bundle"
ITEM.model = "models/mosi/fallout4/props/junk/hidebundle.mdl"
ITEM.description = "A bundle of hide used for crafting."
ITEM.category = "Crafting Material"
ITEM.width = 1
ITEM.height = 1