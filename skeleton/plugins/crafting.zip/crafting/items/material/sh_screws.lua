ITEM.name = "Screws"
ITEM.model = "models/mosi/fallout4/props/junk/components/screws.mdl"
ITEM.description = "Screws used for crafting."
ITEM.category = "Crafting Material"
ITEM.width = 1
ITEM.height = 1