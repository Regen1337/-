ITEM.name = "Leather"
ITEM.model = "models/mosi/fallout4/props/junk/components/leather.mdl"
ITEM.description = "Leather used for crafting."
ITEM.category = "Crafting Material"
ITEM.width = 1
ITEM.height = 1