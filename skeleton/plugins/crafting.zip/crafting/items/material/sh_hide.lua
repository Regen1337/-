ITEM.name = "Hide"
ITEM.model = "models/mosi/fallout4/props/junk/hide.mdl"
ITEM.description = "A piece of hide used for crafting."
ITEM.category = "Crafting Material"
ITEM.width = 1
ITEM.height = 1