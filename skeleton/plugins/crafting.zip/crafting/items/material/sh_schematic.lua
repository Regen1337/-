ITEM.name = "Schematic"
ITEM.model = "models/mosi/fallout4/props/junk/schematic.mdl"
ITEM.description = "A schematic used for crafting."
ITEM.category = "Crafting Material"
ITEM.width = 1
ITEM.height = 1