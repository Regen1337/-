ITEM.name = "Gears"
ITEM.model = "models/mosi/fallout4/props/junk/components/gears.mdl"
ITEM.description = "Gears used for crafting."
ITEM.category = "Crafting Material"
ITEM.width = 1
ITEM.height = 1