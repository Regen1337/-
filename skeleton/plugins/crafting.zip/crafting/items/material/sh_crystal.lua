ITEM.name = "Crystal"
ITEM.model = "models/mosi/fallout4/props/junk/components/crystal.mdl"
ITEM.description = "Crystal used for crafting."
ITEM.category = "Crafting Material"
ITEM.width = 1
ITEM.height = 1