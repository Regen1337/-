ITEM.name = "Mod Crate"
ITEM.model = "models/mosi/fallout4/props/junk/modcrate.mdl"
ITEM.description = "A mod crate used for crafting."
ITEM.category = "Crafting Material"
ITEM.width = 1
ITEM.height = 1