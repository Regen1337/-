ITEM.name = "Hammer"
ITEM.model = "models/mosi/fallout4/props/junk/hammer03.mdl"
ITEM.description = "A hammer used for crafting."
ITEM.category = "Crafting Material"
ITEM.width = 1
ITEM.height = 1