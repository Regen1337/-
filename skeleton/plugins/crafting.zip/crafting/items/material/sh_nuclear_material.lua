ITEM.name = "Nuclear Material"
ITEM.model = "models/mosi/fallout4/props/junk/components/nuclear.mdl"
ITEM.description = "Nuclear material used for crafting."
ITEM.category = "Crafting Material"
ITEM.width = 1
ITEM.height = 1