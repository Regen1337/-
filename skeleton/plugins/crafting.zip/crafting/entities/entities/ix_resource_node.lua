AddCSLuaFile()
-- Helix entity that will be a mineable resource, will have a networkable ore name and amount
local PLUGIN = PLUGIN

ENT.Type = "anim"
ENT.PrintName = "Resource"
ENT.Category = "Helix"
ENT.Spawnable = true
ENT.AdminOnly = true
ENT.bNoPersist = true

function ENT:SetupDataTables()
    self:NetworkVar("String", 0, "OreName")
    self:NetworkVar("Int", 0, "OreAmount")
end

if (SERVER) then
    function ENT:Initialize()
        local random_rock = table.Random(PLUGIN.rocks)

        self:PhysicsInit(SOLID_VPHYSICS)
        self:SetMoveType(MOVETYPE_VPHYSICS)
        self:SetSolid(SOLID_VPHYSICS)
        self:PrecacheGibs()

        self:ChangeRockType(random_rock, true)

        local physObj = self:GetPhysicsObject()

        if (IsValid(physObj)) then
            physObj:Wake()
        end
    end

    function ENT:GetRockType()
        return self.rockType
    end

    function ENT:SetRockType(rockType)
        self.rockType = rockType
    end

    function ENT:ChangeRockType(rockType, bInit)
        self:SetRockType(rockType)
        self:SetModel(rockType.mdl)
        if !(bInit) then self:SetOreName(string.format("%s %s", rockType.name, self:GetOreName())) end

        if (bInit) then
            local random_ore = PLUGIN:GetRandomOre().uniqueID
            self:SetOre(random_ore)
            self:SetOreAmount(math.random(rockType.min, rockType.max))
            self:SetColor(self:GetOreColor())
        end
    end

    function ENT:GetOre()
        return self.ore
    end

    function ENT:SetOre(ore)
        self.ore = ore
        self:SetOreName(string.format("%s %s", self:GetRockType().name, PLUGIN:GetOre(ore).name))
    end

    function ENT:GetOreColor()
        return PLUGIN.GetOre(self:GetOre()).color or Color(255, 255, 255)
    end

    -- ent get ore table
    function ENT:GetOreTable()
        return PLUGIN.GetOre(self:GetOre())
    end

    -- on mined effect
    function ENT:OnMinedEffect()
        local effectData = EffectData()
        effectData:SetOrigin(self:GetPos())
        util.Effect("GlassImpact", effectData)
        self:EmitSound("physics/concrete/boulder_impact_hard" .. math.random(1, 4) .. ".wav", 75, math.random(80, 120))
    end

    -- mining with stage detection based on the current ore amount and current rock type
    function ENT:OnMined(ply)
        local rockType = self:GetRockType()
        local oreAmount = self:GetOreAmount()

        if (oreAmount > 0) then
            self:SetOreAmount(oreAmount - 1)
            self:OnMinedEffect()

            if (oreAmount - 1 <= rockType.min) then
                self:ChangeRockType(PLUGIN:GetRockTypeByNumber(oreAmount - 1))
            end
        else
            PLUGIN:CacheRock(self)
            self:Remove()
        end
    end

    function ENT:Use(activator, caller)
        self:OnMined(activator)
    end

end