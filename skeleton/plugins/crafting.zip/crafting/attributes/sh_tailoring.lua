ATTRIBUTE.name = "Tailoring"
ATTRIBUTE.description = "Your ability to craft clothing and armor."
ATTRIBUTE.noStartBonus = true