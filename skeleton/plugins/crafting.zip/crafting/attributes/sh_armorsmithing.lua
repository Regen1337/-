ATTRIBUTE.name = "Armor Smithing"
ATTRIBUTE.description = "Affects your ability to craft armor."
ATTRIBUTE.noStartBonus = true