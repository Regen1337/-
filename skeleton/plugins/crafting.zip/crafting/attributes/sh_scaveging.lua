ATTRIBUTE.name = "Scavenging"
ATTRIBUTE.description = "Affects how much you can find in the world, and breaking down items."
ATTRIBUTE.noStartBonus = true