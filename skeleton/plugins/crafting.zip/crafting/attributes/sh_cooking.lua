ATTRIBUTE.name = "Cooking"
ATTRIBUTE.description = "Affects your ability to cook food."
ATTRIBUTE.noStartBonus = true