ATTRIBUTE.name = "Herbalism"
ATTRIBUTE.description = "Affects your ability to use herbs."
ATTRIBUTE.noStartBonus = true