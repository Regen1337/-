ATTRIBUTE.name = "Smithing"
ATTRIBUTE.description = "Your ability to craft items using metal."
ATTRIBUTE.noStartBonus = true