ATTRIBUTE.name = "Carpentry"
ATTRIBUTE.description = "Affects your ability to craft wooden items."
ATTRIBUTE.noStartBonus = true