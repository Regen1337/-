ATTRIBUTE.name = "Gun Smithing"
ATTRIBUTE.description = "The ability to craft and repair firearms."
ATTRIBUTE.noStartBonus = true