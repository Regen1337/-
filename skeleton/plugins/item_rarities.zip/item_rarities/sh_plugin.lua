local PLUGIN = PLUGIN

PLUGIN.name = "Item Rarities"
PLUGIN.author = "regen"
PLUGIN.description = "Adds rarities to items, which can be used for crafting and other things"

ix.item.rarities = ix.item.rarities or {}
ix.item.rarities.list = ix.item.rarities.list or {}

-- each rarity has a name, color, and a chance to be generated when looted
-- rarities also have scales for things such as item price, weapon damage, damage resistance, and healing, ammo amount, etc.
-- rarities will need a chance factor for generating a random rarity
-- rarity scales are a multiplier for the base value of the item

--[==[
    Rarities List:
    Common - #808080
    Standard - #00FF00
    Special - #0000FF
    Superior - #800080
    Epic - #FFA500
    Legendary - #FFD700
    Ascended - #FF00FF
    Eternal - #FF0000
]==]


local rarities = ix.item.rarities

function rarities:register(name, color, chance, scales)
    self.list[name] = {
        name = name,
        color = color,
        chance = chance,
        scales = scales
    }

    return self.list[name]
end

function rarities:get(name)
    return self.list[name]
end

function rarities:getAll()
    return self.list
end

-- function that will generate a random rarity based on the chance factor
-- optionally, you can pass a float value that will boost the chance factor, the float will be a value 1 - 100
-- this is useful for things like crafting, where you can boost the chance of getting a higher rarity based on the characters crafting skill
-- you can also optionally specify a minimum rarity, which will be the lowest rarity that can be generated
function rarities:generate(chanceBoost, minRarity)
    local rarities = self:getAll()
    local totalChance = 0

    for _, rarity in pairs(rarities) do
        totalChance = totalChance + rarity.chance
    end

    local chance = math.random(0, totalChance)

    if (chanceBoost) then
        chance = chance + chanceBoost
    end

    local currentChance = 0

    for _, rarity in pairs(rarities) do
        currentChance = currentChance + rarity.chance

        if (chance <= currentChance) then
            if (minRarity) then
                if (rarity.chance < minRarity.chance) then
                    return minRarity
                end
            end

            return rarity
        end
    end
end


function rarities:testGeneration(generations, chanceBoost, minRarity)
    local rarityCounts = {}

    for i = 1, generations do
        local rarity = self:generate(chanceBoost, minRarity)

        if rarityCounts[rarity.name] then
            rarityCounts[rarity.name] = rarityCounts[rarity.name] + 1
        else
            rarityCounts[rarity.name] = 1
        end
    end

    print("Rarity Generation Test Results:")
    print("--------------------------------")

    local totalGenerated = generations

    for rarityName, count in pairs(rarityCounts) do
        local percentage = (count / totalGenerated) * 100
        print(rarityName .. ": " .. count .. " (" .. string.format("%.2f", percentage) .. "%)")
    end)
end

do
    rarities:register("Common", Color(128, 128, 128), 0.5, {
        price = 1,
        damage = 1,
        resistance = 1,
        healing = 1,
        ammo = 1
    })

    rarities:register("Standard", Color(0, 255, 0), 0.3, {
        price = 1.5,
        damage = 1.5,
        resistance = 1.5,
        healing = 1.5,
        ammo = 1.5
    })

    rarities:register("Special", Color(0, 0, 255), 0.1, {
        price = 2,
        damage = 2,
        resistance = 2,
        healing = 2,
        ammo = 2
    })

    rarities:register("Superior", Color(128, 0, 128), 0.05, {
        price = 2.5,
        damage = 2.5,
        resistance = 2.5,
        healing = 2.5,
        ammo = 2.5
    })

    rarities:register("Epic", Color(255, 165, 0), 0.03, {
        price = 3,
        damage = 3,
        resistance = 3,
        healing = 3,
        ammo = 3
    })

    rarities:register("Legendary", Color(255, 215, 0), 0.01, {
        price = 3.5,
        damage = 3.5,
        resistance = 3.5,
        healing = 3.5,
        ammo = 3.5
    })

    rarities:register("Ascended", Color(255, 0, 255), 0.005, {
        price = 4,
        damage = 4,
        resistance = 4,
        healing = 4,
        ammo = 4
    })

    rarities:register("Eternal", Color(255, 0, 0), 0.001, {
        price = 5,
        damage = 5,
        resistance = 5,
        healing = 5,
        ammo = 5
    })
end

ix.util.Include("sh_meta.lua")